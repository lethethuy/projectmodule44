create
    definer = root@localhost procedure findOrderById(IN newId int)
begin
    select * from orders where id = newId;
end;

