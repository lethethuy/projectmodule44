create
    definer = root@localhost procedure products()
begin
    select * from products;
end;

