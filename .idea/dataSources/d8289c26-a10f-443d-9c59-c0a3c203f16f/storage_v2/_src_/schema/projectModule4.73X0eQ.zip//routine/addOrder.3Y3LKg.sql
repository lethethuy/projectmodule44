create
    definer = root@localhost procedure addOrder(IN newUserId int, IN newOrderAt datetime, IN newTotalPrice int,
                                                IN newPhone int, IN newAddress varchar(255), IN newName varchar(255),
                                                IN newStatus int, OUT newOrderId int)
begin
    insert into orders(user_id,order_at,total_price,phone,adrress,name,status)
    values 
    (newUserId,newOrderAt,newTotalPrice,newPhone,newAddress,newName,newStatus);
    select distinct last_insert_id() into newOrderId from orders;
end;

