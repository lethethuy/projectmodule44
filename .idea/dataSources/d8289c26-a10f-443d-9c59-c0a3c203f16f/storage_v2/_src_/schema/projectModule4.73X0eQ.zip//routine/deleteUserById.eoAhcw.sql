create
    definer = root@localhost procedure deleteUserById(IN newId int)
begin
    delete from user where id = newId;
end;

