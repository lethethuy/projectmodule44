create
    definer = root@localhost procedure deleteById(IN newId int)
begin
    delete from products where id = newId;
end;

