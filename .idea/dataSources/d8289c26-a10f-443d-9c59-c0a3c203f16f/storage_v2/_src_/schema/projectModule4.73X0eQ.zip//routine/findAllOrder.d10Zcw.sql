create
    definer = root@localhost procedure findAllOrder()
begin
    select * from orders;
end;

