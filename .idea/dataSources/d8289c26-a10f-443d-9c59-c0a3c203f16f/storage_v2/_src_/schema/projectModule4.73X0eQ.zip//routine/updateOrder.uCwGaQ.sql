create
    definer = root@localhost procedure updateOrder(IN newId int, IN newUserId int, IN newOrderAt datetime,
                                                   IN newTotalPrice int, IN newPhone int, IN newAddress varchar(255),
                                                   IN newName varchar(255), IN newStatus int)
begin
    update user set user_id = newUserId, order_at = newOrderAt, 
    total_price = newTotalPrice, phone = newPhone, adrress = newAddress,name = newName,status=newStatus
    where id=newId;
end;

