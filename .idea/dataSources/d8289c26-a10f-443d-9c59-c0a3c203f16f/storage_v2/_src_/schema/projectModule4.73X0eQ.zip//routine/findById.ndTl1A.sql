create
    definer = root@localhost procedure findById(IN newId int)
begin
    select * from products where id= newId;
end;

