create
    definer = root@localhost procedure findAllUser()
begin
    select * from user;
end;

