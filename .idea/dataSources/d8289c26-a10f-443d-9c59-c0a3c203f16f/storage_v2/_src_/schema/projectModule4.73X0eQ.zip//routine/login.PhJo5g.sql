create
    definer = root@localhost procedure login(IN newEmail varchar(255), IN newPassword varchar(255))
begin
select * from user where email = newEmail and password = newPassword;
end;

