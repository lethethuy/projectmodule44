create
    definer = root@localhost procedure addOrderDetail(IN newProductId int, IN newPrice double, IN newQuantity int,
                                                      IN newOrder int)
begin
    insert into orders_detail(productId,price,quantity,order_id)
    values 
    (newProductId, newPrice,newQuantity,newOrder);
end;

