create
    definer = root@localhost procedure lockUser(IN newId int)
begin
    update user set status = if(user.status=1 and user.role_id !=2,1,0) where id = newId;
end;

