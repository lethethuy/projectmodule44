create
    definer = root@localhost procedure addProducts(IN newProduct_name varchar(255), IN newImage_url varchar(255),
                                                   IN newDescription text, IN newStock int, IN newCatalog_id int,
                                                   IN newImport_price double, IN newStatus tinyint(1))
begin
    insert into products(product_name, image_url,description,stock,catalog_id,price,status )
    values 
    (newProduct_name,newImage_url,newDescription,newStock,newCatalog_id,newImport_price,newStatus);
end;

