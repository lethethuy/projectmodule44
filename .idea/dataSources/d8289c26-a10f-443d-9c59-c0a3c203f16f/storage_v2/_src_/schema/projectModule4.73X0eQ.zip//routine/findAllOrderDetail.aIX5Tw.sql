create
    definer = root@localhost procedure findAllOrderDetail()
begin
    select * from orders_detail;
end;

