create
    definer = root@localhost procedure findUserById(IN newId int)
begin
    select * from user where id = newId;
end;

