create
    definer = root@localhost procedure deleteOrderById(IN newId int)
begin
    delete from orders where id = newId;
end;

